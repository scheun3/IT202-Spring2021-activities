let map;

function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: 41.87209602844411, lng: -87.64793737310494 },
    zoom: 8,
  });
} 